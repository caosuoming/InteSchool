import JSZip from "jszip";
import katex from "katex";
import { ommlToLatex } from "./omml-to-latex";

export type DocxItemType = "heading" | "paragraph" | "image" | "formula" | "list";

export interface DocxItem {
  type: DocxItemType;
  level?: number;
  text?: string;
  src?: string;
  alt?: string;
  width?: number;
  height?: number;
  latex?: string;
  /** 公式是否为行内公式（false 表示块级公式） */
  displayMode?: boolean;
}

export interface ExtractedQuestion {
  type: string;
  stem: string;
  options?: string[];
  answer: string;
  analysis: string;
  difficulty: number;
}

export interface ExtractedKnowledge {
  title: string;
  content: string;
}

export interface DocxParseResult {
  items: DocxItem[];
  questions: ExtractedQuestion[];
  knowledgeBlocks: ExtractedKnowledge[];
}

const NAMESPACES = {
  w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
  a: "http://schemas.openxmlformats.org/drawingml/2006/main",
  pic: "http://schemas.openxmlformats.org/drawingml/2006/picture",
  r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
  m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
  v: "urn:schemas-microsoft-com:vml",
  o: "urn:schemas-microsoft-com:office:office",
  wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
};

export async function parseDocxFromBase64(base64Content: string): Promise<DocxParseResult> {
  try {
    console.log("[DOCX解析] 开始解析，base64长度:", base64Content.length);
    
    const base64Data = base64Content.split(",")[1];
    console.log("[DOCX解析] base64数据长度:", base64Data?.length || 0);
    
    const zip = await JSZip.loadAsync(base64Data, { base64: true });
    console.log("[DOCX解析] ZIP加载成功");
    
    const contentXml = await zip.file("word/document.xml")?.async("string");
    if (!contentXml) {
      throw new Error("无法读取文档内容");
    }
    console.log("[DOCX解析] document.xml长度:", contentXml.length);
    
    const relsXml = await zip.file("word/_rels/document.xml.rels")?.async("string");
    const relationships = parseRelationships(relsXml || "");
    console.log("[DOCX解析] 关系数:", Object.keys(relationships).length);
    
    const imageData: Record<string, string> = {};
    const embeddingData: Record<string, string> = {};
    for (const [relId, target] of Object.entries(relationships)) {
      if (target.startsWith("media/") || target.startsWith("image/")) {
        const zipPath = `word/${target}`;
        const mediaFile = zip.file(zipPath);
        if (mediaFile) {
          try {
            const base64 = await mediaFile.async("base64");
            const ext = target.split(".").pop()?.toLowerCase() || "png";
            const mimeType = getImageMimeType(ext);
            imageData[relId] = `data:${mimeType};base64,${base64}`;
          } catch (e) {
            console.warn("[DOCX解析] 图片读取失败:", target, e);
          }
        }
      } else if (target.startsWith("embeddings/")) {
        const zipPath = `word/${target}`;
        const embeddingFile = zip.file(zipPath);
        if (embeddingFile) {
          try {
            const base64 = await embeddingFile.async("base64");
            embeddingData[relId] = base64;
          } catch (e) {
            console.warn("[DOCX解析] embedding读取失败:", target, e);
          }
        }
      }
    }
    console.log("[DOCX解析] 图片数:", Object.keys(imageData).length, "embedding数:", Object.keys(embeddingData).length);
    
    const items = parseDocumentXml(contentXml, imageData, embeddingData);
    console.log("[DOCX解析] 解析完成，项目数:", items.length);
    
    const plainTextItems = items
      .filter(i => i.type === "heading" || i.type === "paragraph" || i.type === "list")
      .map(i => ({ type: i.type as "heading" | "paragraph" | "list", level: i.level, text: i.text || "" }));
    
    const { questions, knowledgeBlocks } = extractFromItems(plainTextItems);
    
    console.log("[DOCX解析] 提取完成，题目数:", questions.length, "知识点数:", knowledgeBlocks.length);
    
    return { items, questions, knowledgeBlocks };
  } catch (e) {
    console.error("[DOCX解析] 错误:", e);
    throw e;
  }
}

function getImageMimeType(ext: string): string {
  const map: Record<string, string> = {
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    gif: "image/gif",
    bmp: "image/bmp",
    webp: "image/webp",
    svg: "image/svg+xml",
    tif: "image/tiff",
    tiff: "image/tiff",
    emf: "image/emf",
    wmf: "image/wmf",
  };
  return map[ext] || "image/png";
}

/**
 * 生成 MathType 公式占位 SVG 图片（base64 编码，更可靠）
 */
function generateMathTypePlaceholder(label: string, width: number, height: number): string {
  const w = Math.max(width, 80);
  const h = Math.max(height, 24);
  const displayLabel = label || "公式";
  const escapedLabel = displayLabel
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><rect x="0" y="0" width="${w}" height="${h}" rx="4" fill="#f8f5e9" stroke="#d4a24c" stroke-width="1"/><text x="${w / 2}" y="${h / 2 + 5}" text-anchor="middle" font-family="serif" font-size="${Math.min(h * 0.6, 16)}" fill="#8b6914">${escapedLabel}</text></svg>`;
  // 使用 base64 编码，避免 encodeURIComponent 对 # 等字符的编码问题
  const bytes = new TextEncoder().encode(svg);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return `data:image/svg+xml;base64,${btoa(binary)}`;
}

/**
 * 判断图片 MIME 类型是否为浏览器不支持的格式（WMF/EMF）
 */
function isUnsupportedImageFormat(src: string): boolean {
  return /data:image\/(wmf|emf|x-wmf|x-emf)/i.test(src);
}

function parseRelationships(xml: string): Record<string, string> {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, "application/xml");
  const rels = doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/package/2006/relationships", "Relationship");
  for (let i = 0; i < rels.length; i++) {
    const rel = rels[i];
    const id = rel.getAttribute("Id") || "";
    const target = rel.getAttribute("Target") || "";
    relationships[id] = target;
  }
  return relationships;
}

async function parseDocumentXml(xml: string, imageData: Record<string, string>, embeddingData: Record<string, string> = {}): Promise<DocxItem[]> {
  const items: DocxItem[] = [];
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, "application/xml");
  
  const body = doc.getElementsByTagNameNS(NAMESPACES.w, "body")[0];
  if (!body) return items;
  
  const children = Array.from(body.children);
  
  for (const child of children) {
    if (child.namespaceURI !== NAMESPACES.w) continue;
    const tag = child.localName;
    
    if (tag === "p") {
      const paragraphItems = await parseParagraph(child, imageData, embeddingData);
      items.push(...paragraphItems);
    } else if (tag === "tbl") {
      const tableItems = await parseTable(child, imageData, embeddingData);
      items.push(...tableItems);
    }
  }
  
  return items;
}

async function parseParagraph(p: Element, imageData: Record<string, string>, embeddingData: Record<string, string> = {}): Promise<DocxItem[]> {
  const results: DocxItem[] = [];
  
  let text = "";
  let hasImage = false;
  let hasFormula = false;
  let formulaText = "";
  const images: DocxItem[] = [];
  
  const processChild = async (node: Node) => {
    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as Element;
      const ns = el.namespaceURI;
      const tag = el.localName;
      
      if (ns === NAMESPACES.w && tag === "t") {
        text += el.textContent || "";
        return;
      }
      
      if (ns === NAMESPACES.w && tag === "br") {
        text += "\n";
        return;
      }
      
      if (ns === NAMESPACES.w && tag === "tab") {
        text += "\t";
        return;
      }
      
      if (ns === NAMESPACES.m && (tag === "oMath" || tag === "oMathPara")) {
        hasFormula = true;
        const latex = ommlToLatex(el);
        if (latex) {
          formulaText += (formulaText ? " " : "") + latex;
          // 同时把 LaTeX 嵌入到文本中，用 $...$ 标记，供题库列表渲染
          text += ` $${latex}$`;
        }
        return;
      }
      
      if (ns === NAMESPACES.w && tag === "drawing") {
        const img = extractImageFromDrawing(el, imageData);
        if (img) {
          images.push(img);
          hasImage = true;
        }
        return;
      }
      
      if (ns === NAMESPACES.v && tag === "imagedata") {
        const relId = el.getAttribute("o:title") || "";
        if (imageData[relId]) {
          images.push({
            type: "image",
            src: imageData[relId],
          });
          hasImage = true;
        }
        return;
      }
      
      if (ns === NAMESPACES.w && tag === "pict") {
        const vmlShapes = el.getElementsByTagNameNS(NAMESPACES.v, "shape");
        for (let i = 0; i < vmlShapes.length; i++) {
          const shape = vmlShapes[i];
          const imagedata = shape.getElementsByTagNameNS(NAMESPACES.v, "imagedata")[0];
          if (imagedata) {
            const relId = imagedata.getAttribute("o:title") || "";
            const rId = imagedata.getAttribute("r:id") || "";
            const src = imageData[relId] || imageData[rId] || "";
            if (src) {
              const style = shape.getAttribute("style") || "";
              const widthMatch = style.match(/width:\s*([\d.]+)pt/i);
              const heightMatch = style.match(/height:\s*([\d.]+)pt/i);
              images.push({
                type: "image",
                src,
                width: widthMatch ? parseFloat(widthMatch[1]) : undefined,
                height: heightMatch ? parseFloat(heightMatch[1]) : undefined,
              });
              hasImage = true;
            }
          }
        }
        return;
      }

      // 处理 MathType OLE 嵌入对象（w:object）
      // MathType 公式以 OLE 对象形式嵌入，包含一个预览图片和一个 embedding 文件
      // embedding 文件包含 OMML 格式的公式，可以转换为 LaTeX 显示
      if (ns === NAMESPACES.w && tag === "object") {
        try {
          // 检查是否是 MathType 公式（使用命名空间感知方法 + 降级兼容）
          const oleObjects = el.getElementsByTagNameNS(NAMESPACES.o, "OLEObject").length > 0
            ? el.getElementsByTagNameNS(NAMESPACES.o, "OLEObject")
            : el.getElementsByTagName("o:OLEObject");
          let isMathType = false;
          let embedRId = "";
          for (let i = 0; i < oleObjects.length; i++) {
            const progId = oleObjects[i].getAttribute("ProgID") || "";
            embedRId = oleObjects[i].getAttribute("r:id") || embedRId;
            if (progId.includes("Equation") || progId.includes("MathType") || progId.includes("Math")) {
              isMathType = true;
            }
          }

          // 获取对象尺寸（dxa 转像素: dxa / 20 ≈ px）
          const oWidth = el.getAttribute("w:dxaOrig") || el.getAttribute("dxaOrig") || "";
          const oHeight = el.getAttribute("w:dyaOrig") || el.getAttribute("dyaOrig") || "";
          const objWidth = oWidth ? Math.round(parseInt(oWidth) / 20) : 200;
          const objHeight = oHeight ? Math.round(parseInt(oHeight) / 20) : 40;

          // 尝试从 embedding 中提取 OMML 并转换为 LaTeX
          let latexFromEmbedding = "";
          if (embedRId && embeddingData[embedRId]) {
            try {
              const embedBase64 = embeddingData[embedRId];
              const embedBytes = new Uint8Array(atob(embedBase64).split("").map(c => c.charCodeAt(0)));
              const embedZip = await JSZip.loadAsync(embedBytes);
              const embedDoc = await embedZip.file("MML/math.mml")?.async("string");
              if (embedDoc) {
                latexFromEmbedding = ommlToLatex(embedDoc);
                console.log("[DOCX解析] MathType OMML转LaTeX成功:", latexFromEmbedding.substring(0, 50));
              }
            } catch (embedError) {
              console.warn("[DOCX解析] MathType embedding解析失败:", embedError);
            }
          }

          // 如果成功转换为 LaTeX，创建公式项
          if (latexFromEmbedding) {
            hasFormula = true;
            formulaText = latexFromEmbedding;
            // 同时把 LaTeX 嵌入到文本中，用 $...$ 标记，供题库列表渲染
            text += ` $${latexFromEmbedding}$`;
            return;
          }

          // 提取预览图片（通常是 VML imagedata）
          const vmlImagedata = el.getElementsByTagNameNS(NAMESPACES.v, "imagedata");
          let foundImage = false;
          for (let i = 0; i < vmlImagedata.length; i++) {
            const imagedata = vmlImagedata[i];
            const rId = imagedata.getAttribute("r:id") || "";
            const title = imagedata.getAttribute("o:title") || "";
            const src = imageData[rId] || imageData[title] || "";
            if (src) {
              if (isUnsupportedImageFormat(src)) {
                const placeholderSrc = generateMathTypePlaceholder(isMathType ? "公式" : "对象", objWidth, objHeight);
                images.push({
                  type: "image",
                  src: placeholderSrc,
                  alt: isMathType ? "MathType公式" : "嵌入对象",
                  width: objWidth,
                  height: objHeight,
                });
              } else {
                images.push({
                  type: "image",
                  src,
                  alt: isMathType ? "MathType公式" : "嵌入对象",
                });
              }
              foundImage = true;
            }
          }

          // 也检查 DrawingML 格式的预览图片
          const drawings = el.getElementsByTagNameNS(NAMESPACES.w, "drawing");
          for (let i = 0; i < drawings.length; i++) {
            const img = extractImageFromDrawing(drawings[i], imageData);
            if (img) {
              if (isUnsupportedImageFormat(img.src)) {
                img.src = generateMathTypePlaceholder(isMathType ? "公式" : "对象", img.width || objWidth, img.height || objHeight);
              }
              images.push(img);
              foundImage = true;
            }
          }

          if (foundImage) {
            hasImage = true;
          } else if (isMathType) {
            // MathType 公式但没有任何预览图：生成占位 SVG
            const placeholderSrc = generateMathTypePlaceholder("公式", objWidth, objHeight);
            images.push({
              type: "image",
              src: placeholderSrc,
              alt: "MathType公式",
              width: objWidth,
              height: objHeight,
            });
            hasImage = true;
          }
        } catch (oleError) {
          console.error("[DOCX解析] OLE对象解析失败，跳过:", oleError);
        }
        return;
      }
      
      if (ns === NAMESPACES.w && tag === "sdt") {
        const content = el.getElementsByTagNameNS(NAMESPACES.w, "sdtContent")[0];
        if (content) {
          for (const childNode of Array.from(content.childNodes)) {
            await processChild(childNode);
          }
        }
        return;
      }
      
      for (const childNode of Array.from(el.childNodes)) {
        await processChild(childNode);
      }
    }
  };
  
  for (const childNode of Array.from(p.childNodes)) {
    await processChild(childNode);
  }
  
  const headingStyle = getParagraphStyle(p);
  const levelMatch = headingStyle?.match(/^Heading(\d)$/i);
  
  const hasText = text.trim().length > 0;

  if (hasImage && images.length > 0) {
    if (hasText) {
      if (levelMatch) {
        results.push({ type: "heading", level: parseInt(levelMatch[1]), text: text.trim() });
      } else {
        results.push({ type: "paragraph", text: text.trim() });
      }
    }
    results.push(...images);
  } else if (hasFormula) {
    // 判断是行内公式还是块级公式：如果段落有文本，公式是行内的
    const isInline = hasText;
    if (hasText) {
      if (levelMatch) {
        results.push({ type: "heading", level: parseInt(levelMatch[1]), text: text.trim() });
      } else {
        results.push({ type: "paragraph", text: text.trim() });
      }
    }
    // 始终创建公式项，即使 formulaText 为空也显示降级占位符
    results.push({
      type: "formula",
      text: formulaText || text.trim() || "[公式]",
      latex: formulaText || "",
      displayMode: !isInline,
    });
  } else if (hasText) {
    if (levelMatch) {
      results.push({ type: "heading", level: parseInt(levelMatch[1]), text: text.trim() });
    } else {
      results.push({ type: "paragraph", text: text.trim() });
    }
  }
  
  return results;
}

function getParagraphStyle(p: Element): string | null {
  const pPr = p.getElementsByTagNameNS(NAMESPACES.w, "pPr")[0];
  if (!pPr) return null;
  const pStyle = pPr.getElementsByTagNameNS(NAMESPACES.w, "pStyle")[0];
  if (!pStyle) return null;
  return pStyle.getAttribute("w:val") || pStyle.getAttribute("val") || null;
}

function extractImageFromDrawing(drawing: Element, imageData: Record<string, string>): DocxItem | null {
  const blips = drawing.getElementsByTagNameNS(NAMESPACES.a, "blip");
  for (let i = 0; i < blips.length; i++) {
    const blip = blips[i];
    const embed = blip.getAttribute("r:embed") || blip.getAttribute("embed") || "";
    if (embed && imageData[embed]) {
      const extents = drawing.getElementsByTagNameNS(NAMESPACES.a, "ext")[0];
      let width: number | undefined;
      let height: number | undefined;
      if (extents) {
        const cx = extents.getAttribute("cx");
        const cy = extents.getAttribute("cy");
        if (cx && cy) {
          width = parseInt(cx) / 9525;
          height = parseInt(cy) / 9525;
        }
      }
      return {
        type: "image",
        src: imageData[embed],
        width,
        height,
      };
    }
  }
  return null;
}

async function parseTable(tbl: Element, imageData: Record<string, string>, embeddingData: Record<string, string> = {}): Promise<DocxItem[]> {
  const items: DocxItem[] = [];
  const rows = tbl.getElementsByTagNameNS(NAMESPACES.w, "tr");
  
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const cells = row.getElementsByTagNameNS(NAMESPACES.w, "tc");
    const cellTexts: string[] = [];
    
    for (let j = 0; j < cells.length; j++) {
      const cell = cells[j];
      const cellText = getTextFromElement(cell, imageData);
      cellTexts.push(cellText.trim());
    }
    
    items.push({
      type: "paragraph",
      text: cellTexts.join("    "),
    });
  }
  
  return items;
}

function getTextFromElement(el: Element, imageData: Record<string, string>): string {
  let text = "";
  
  const processNode = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      text += node.textContent || "";
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const elem = node as Element;
      const ns = elem.namespaceURI;
      const tag = elem.localName;
      
      if (ns === NAMESPACES.w && tag === "t") {
        text += elem.textContent || "";
        return;
      }
      if (ns === NAMESPACES.w && tag === "br") {
        text += "\n";
        return;
      }
      if (ns === NAMESPACES.w && tag === "tab") {
        text += "\t";
        return;
      }
      if (ns === NAMESPACES.w && tag === "drawing" || (ns === NAMESPACES.v && tag === "imagedata")) {
        text += "[图片]";
        return;
      }
      if (ns === NAMESPACES.m && (tag === "oMath" || tag === "oMathPara")) {
        text += "[公式]";
        return;
      }
      
      Array.from(node.childNodes).forEach(processNode);
    }
  };
  
  Array.from(el.childNodes).forEach(processNode);
  return text;
}

function extractFromItems(items: Array<{ type: "heading" | "paragraph" | "list"; level?: number; text: string }>): {
  questions: ExtractedQuestion[];
  knowledgeBlocks: ExtractedKnowledge[];
} {
  const questions: ExtractedQuestion[] = [];
  const knowledgeBlocks: ExtractedKnowledge[] = [];
  
  let currentKnowledge: ExtractedKnowledge | null = null;
  let currentQuestion: Partial<ExtractedQuestion> = {};
  let inQuestion = false;
  let collectingOptions = false;
  const optionsBuffer: string[] = [];
  
  const isKnowledgeHeading = (text: string): boolean => {
    return /^[一二三四五六七八九十]+[、．.）)]/.test(text) ||
           /^第[一二三四五六七八九十\d]+[章节编]/i.test(text) ||
           /^(知识点|知识要点|学习目标|教学重点|教学难点)/i.test(text);
  };
  
  const isQuestionStart = (text: string): boolean => {
    return /^(例|例题|习题|练习|选择题|填空题|判断题|解答题)\s*[\d一二三四五六七八九十]+[、．.）)]/.test(text) ||
           /^\s*[\d一二三四五六七八九十]+[、．.）)]/.test(text) && text.length > 5;
  };
  
  const isOption = (text: string): boolean => {
    return /^[ABCDabcd][、．.）)]/.test(text) ||
           /^[①②③④⑤⑥⑦⑧⑨⑩]/.test(text);
  };
  
  const isAnswer = (text: string): boolean => {
    return /^(【答案】|答案[：:])/.test(text);
  };
  
  const isAnalysis = (text: string): boolean => {
    return /^(【解析】|解析[：:]|【说明】|说明[：:]|【解题思路】|解题思路[：:])/.test(text);
  };
  
  for (const item of items) {
    const text = item.text;
    
    if (!text.trim()) continue;
    
    if (isKnowledgeHeading(text)) {
      if (currentKnowledge && currentKnowledge.content.trim()) {
        knowledgeBlocks.push(currentKnowledge);
      }
      currentKnowledge = { title: text.replace(/^[一二三四五六七八九十]+[、．.）)]/, "").trim(), content: "" };
      inQuestion = false;
      collectingOptions = false;
      continue;
    }
    
    if (isQuestionStart(text)) {
      if (currentKnowledge && currentKnowledge.content.trim()) {
        knowledgeBlocks.push(currentKnowledge);
        currentKnowledge = null;
      }
      if (inQuestion && currentQuestion.stem) {
        questions.push({
          type: (currentQuestion.type as string) || "short",
          stem: currentQuestion.stem || "",
          options: optionsBuffer.length > 0 ? optionsBuffer : undefined,
          answer: currentQuestion.answer || "",
          analysis: currentQuestion.analysis || "",
          difficulty: (currentQuestion.difficulty as number) || 3,
        });
      }
      
      currentQuestion = {
        type: guessQuestionType(text),
        stem: text.replace(/^[\d一二三四五六七八九十]+[、．.）)]/, "").replace(/^(例|例题|习题|练习)\s*/, "").trim(),
        options: undefined,
        answer: "",
        analysis: "",
        difficulty: 3,
      };
      inQuestion = true;
      collectingOptions = true;
      optionsBuffer.length = 0;
      continue;
    }
    
    if (inQuestion) {
      if (isOption(text)) {
        optionsBuffer.push(text.replace(/^[ABCDabcd][、．.）)]/, "").replace(/^[①②③④⑤⑥⑦⑧⑨⑩]/, "").trim());
        continue;
      }
      
      if (isAnswer(text)) {
        currentQuestion.answer = text.replace(/^(【答案】|答案[：:])/, "").trim();
        collectingOptions = false;
        continue;
      }
      
      if (isAnalysis(text)) {
        currentQuestion.analysis = text.replace(/^(【解析】|解析[：:]|【说明】|说明[：:]|【解题思路】|解题思路[：:])/, "").trim();
        continue;
      }
      
      if (collectingOptions) {
        if (optionsBuffer.length > 0) {
          optionsBuffer[optionsBuffer.length - 1] += " " + text;
        }
      } else if (currentQuestion.answer && !currentQuestion.analysis) {
        currentQuestion.analysis += (currentQuestion.analysis ? "\n" : "") + text;
      } else if (!currentQuestion.stem) {
        currentQuestion.stem += text;
      }
    } else if (currentKnowledge) {
      currentKnowledge.content += (currentKnowledge.content ? "\n" : "") + text;
    }
  }
  
  if (inQuestion && currentQuestion.stem) {
    questions.push({
      type: (currentQuestion.type as string) || "short",
      stem: currentQuestion.stem || "",
      options: optionsBuffer.length > 0 ? optionsBuffer : undefined,
      answer: currentQuestion.answer || "",
      analysis: currentQuestion.analysis || "",
      difficulty: (currentQuestion.difficulty as number) || 3,
    });
  }
  
  if (currentKnowledge && currentKnowledge.content.trim()) {
    knowledgeBlocks.push(currentKnowledge);
  }
  
  return { questions, knowledgeBlocks };
}

function guessQuestionType(text: string): string {
  if (/选择题/.test(text)) return "single";
  if (/多选/.test(text)) return "multiple";
  if (/判断题/.test(text)) return "judge";
  if (/填空题/.test(text)) return "short";
  if (/解答题/.test(text)) return "essay";
  if (/计算题/.test(text)) return "essay";
  if (/证明题/.test(text)) return "essay";
  return "short";
}

export function renderDocxItems(items: DocxItem[]): string {
  let html = "";
  for (const item of items) {
    if (item.type === "heading") {
      const tag = `h${Math.min(item.level || 2, 6)}`;
      html += `<${tag} class="font-serif font-semibold text-ink-900 mb-2 mt-4">${escapeHtml(item.text || "")}</${tag}>`;
    } else if (item.type === "paragraph") {
      const text = item.text || "";
      // 检查段落中是否包含行内公式标记
      if (text.includes("[公式]")) {
        // 行内公式已在单独的 formula 项中处理
        const cleanText = text.replace(/\[公式\]/g, "").trim();
        if (cleanText) {
          html += `<p class="text-sm text-ink-700 mb-2 leading-relaxed whitespace-pre-wrap">${escapeHtml(cleanText)}</p>`;
        }
      } else {
        html += `<p class="text-sm text-ink-700 mb-2 leading-relaxed whitespace-pre-wrap">${escapeHtml(text)}</p>`;
      }
    } else if (item.type === "image") {
      const width = item.width ? `max-width: ${Math.min(item.width, 600)}px;` : "max-width: 100%;";
      html += `<div class="my-4 text-center"><img src="${item.src}" alt="${escapeHtml(item.alt || "图片")}" style="${width} height: auto;" class="inline-block rounded border border-ink-200" /></div>`;
    } else if (item.type === "formula") {
      const latex = item.latex || item.text || "";
      const isDisplayMode = item.displayMode !== false; // 默认为块级公式
      if (latex) {
        try {
          const formulaHtml = katex.renderToString(latex, {
            throwOnError: false,
            displayMode: isDisplayMode,
            output: "html",
          });
          if (isDisplayMode) {
            html += `<div class="my-3 text-center overflow-x-auto">${formulaHtml}</div>`;
          } else {
            html += `<span class="inline-block mx-0.5 align-middle">${formulaHtml}</span>`;
          }
        } catch {
          html += `<div class="my-2 px-3 py-2 bg-ink-50 rounded text-ink-700 text-sm font-mono">${escapeHtml(latex)}</div>`;
        }
      } else {
        // 公式转换失败，显示降级占位符
        html += `<div class="my-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded text-amber-700 text-sm">${escapeHtml(item.text || "[公式]")}</div>`;
      }
    } else if (item.type === "list") {
      html += `<li class="text-sm text-ink-700 ml-4 mb-1">${escapeHtml(item.text || "")}</li>`;
    }
  }
  return html;
}

function escapeHtml(text: string): string {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
