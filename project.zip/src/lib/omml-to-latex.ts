/**
 * OMML (Office Math Markup Language) 到 LaTeX 的转换器
 *
 * 用于解析 docx 文档中的数学公式（包括 MathType 和 Word 原生公式），
 * 将其转换为 LaTeX 字符串，再由 KaTeX 渲染显示。
 *
 * 支持的 OMML 元素：
 * - m:r/m:t 文本
 * - m:frac 分式
 * - m:rad 根号
 * - m:sup 上标
 * - m:sub 下标
 * - m:subSup 上下标
 * - m:nary n元运算（求和、积分等）
 * - m:d 定界符（括号）
 * - m:func 函数
 * - m:eqArr 方程组
 * - m:m 矩阵
 * - m:acc 重音符号
 * - m:bar 上划线
 * - m:limLow/limUpp 极限
 */

const MATH_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math";

/**
 * 将 OMML 元素（m:oMath 或 m:oMathPara）转换为 LaTeX 字符串
 */
export function ommlToLatex(mathEl: Element): string {
  const latex = convertNode(mathEl).trim();
  return latex || "";
}

/**
 * 递归转换 OMML 节点
 */
function convertNode(node: Node): string {
  if (node.nodeType === Node.TEXT_NODE) {
    return node.textContent || "";
  }

  if (node.nodeType !== Node.ELEMENT_NODE) return "";

  const el = node as Element;
  const tag = el.localName;

  // 忽略属性元素，只处理内容
  if (isPropertyElement(tag)) {
    return "";
  }

  switch (tag) {
    case "oMath":
    case "oMathPara":
      return convertChildren(el);

    case "r":
      // 数学运行，处理其文本内容
      return convertRun(el);

    case "t":
      // 文本节点
      return escapeLatex(el.textContent || "");

    case "frac":
      return convertFrac(el);

    case "rad":
      return convertRad(el);

    case "sup":
      return convertSup(el);

    case "sub":
      return convertSub(el);

    case "subSup":
      return convertSubSup(el);

    case "nary":
      return convertNary(el);

    case "d":
      return convertDelimiter(el);

    case "func":
      return convertFunc(el);

    case "eqArr":
      return convertEqArr(el);

    case "m":
      return convertMatrix(el);

    case "acc":
      return convertAcc(el);

    case "bar":
      return convertBar(el);

    case "limLow":
      return convertLimLow(el);

    case "limUpp":
      return convertLimUpp(el);

    case "groupChr":
      return convertGroupChr(el);

    case "borderBox":
      return convertBorderBox(el);

    case "box":
    case "sSubSup":
    case "sSup":
    case "sSub":
      return convertChildren(el);

    case "e":
    case "num":
    case "den":
    case "lim":
    case "sup_node":
    case "sub_node":
      return convertChildren(el);

    default:
      // 对于未知元素，递归处理子节点
      return convertChildren(el);
  }
}

function isPropertyElement(tag: string): boolean {
  return [
    "rPr", "ctrlPr", "oMathParaPr", "mPr", "fPr",
    "radPr", "supPr", "subPr", "naryPr", "dPr",
    "funcPr", "eqArrPr", "mPr", "accPr", "barPr",
    "limLowPr", "limUppPr", "groupChrPr", "borderBoxPr",
    "sSubSupPr", "sSupPr", "sSubPr",
  ].includes(tag);
}

function convertChildren(el: Element): string {
  let result = "";
  for (const child of Array.from(el.childNodes)) {
    result += convertNode(child);
  }
  return result;
}

function convertRun(el: Element): string {
  let result = "";
  for (const child of Array.from(el.childNodes)) {
    if (child.nodeType === Node.ELEMENT_NODE) {
      const childEl = child as Element;
      if (childEl.localName === "t") {
        result += escapeLatex(childEl.textContent || "");
      } else if (!isPropertyElement(childEl.localName)) {
        result += convertNode(child);
      }
    }
  }
  return result;
}

/**
 * 分式 m:frac
 * <m:frac><m:num>...</m:num><m:den>...</m:den></m:frac>
 */
function convertFrac(el: Element): string {
  const num = getMathChild(el, "num");
  const den = getMathChild(el, "den");
  return `\\frac{${num}}{${den}}`;
}

/**
 * 根号 m:rad
 * <m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg>...</m:deg><m:e>...</m:e></m:rad>
 */
function convertRad(el: Element): string {
  const deg = getMathChild(el, "deg");
  const e = getMathChild(el, "e");

  // 检查是否隐藏次数
  const radPr = el.getElementsByTagNameNS(MATH_NS, "radPr")[0];
  const degHide = radPr?.getElementsByTagNameNS(MATH_NS, "degHide")[0];
  const hideDeg = degHide?.getAttribute("m:val") === "1" || degHide?.getAttribute("val") === "1";

  if (hideDeg || !deg) {
    return `\\sqrt{${e}}`;
  }
  return `\\sqrt[${deg}]{${e}}`;
}

/**
 * 上标 m:sup
 * <m:sup><m:e>...</m:e><m:sup>...</m:sup></m:sup>
 */
function convertSup(el: Element): string {
  const e = getMathChild(el, "e");
  const sup = getMathChild(el, "sup");
  return `{${e}}^{${sup}}`;
}

/**
 * 下标 m:sub
 * <m:sub><m:e>...</m:e><m:sub>...</m:sub></m:sub>
 */
function convertSub(el: Element): string {
  const e = getMathChild(el, "e");
  const sub = getMathChild(el, "sub");
  return `{${e}}_{${sub}}`;
}

/**
 * 上下标 m:subSup
 * <m:subSup><m:e>...</m:e><m:sub>...</m:sub><m:sup>...</m:sup></m:subSup>
 */
function convertSubSup(el: Element): string {
  const e = getMathChild(el, "e");
  const sub = getMathChild(el, "sub");
  const sup = getMathChild(el, "sup");
  return `{${e}}_{${sub}}^{${sup}}`;
}

/**
 * n元运算 m:nary
 * 求和、积分、乘积等
 */
function convertNary(el: Element): string {
  const naryPr = el.getElementsByTagNameNS(MATH_NS, "naryPr")[0];
  const chrEl = naryPr?.getElementsByTagNameNS(MATH_NS, "chr")[0];
  const chr = chrEl?.getAttribute("m:val") || chrEl?.getAttribute("val") || "∑";

  const operator = mapNaryOperator(chr);

  const sub = getMathChild(el, "sub");
  const sup = getMathChild(el, "sup");
  const e = getMathChild(el, "e");

  let result = operator;
  if (sub) result += `_{${sub}}`;
  if (sup) result += `^{${sup}}`;
  result += ` ${e}`;

  return result;
}

function mapNaryOperator(chr: string): string {
  const map: Record<string, string> = {
    "∑": "\\sum",
    "∫": "\\int",
    "∮": "\\oint",
    "∏": "\\prod",
    "∐": "\\coprod",
    "⋃": "\\bigcup",
    "⋂": "\\bigcap",
    "⨁": "\\bigoplus",
    "⨂": "\\bigotimes",
    "⊕": "\\oplus",
    "⊗": "\\otimes",
  };
  return map[chr] || chr;
}

/**
 * 定界符 m:d
 * 括号、绝对值等
 */
function convertDelimiter(el: Element): string {
  const dPr = el.getElementsByTagNameNS(MATH_NS, "dPr")[0];

  let beginChr = "(";
  let endChr = ")";

  if (dPr) {
    const begChrEl = dPr.getElementsByTagNameNS(MATH_NS, "begChr")[0];
    const endChrEl = dPr.getElementsByTagNameNS(MATH_NS, "endChr")[0];
    beginChr = begChrEl?.getAttribute("m:val") || begChrEl?.getAttribute("val") || "(";
    endChr = endChrEl?.getAttribute("m:val") || endChrEl?.getAttribute("val") || ")";
  }

  const e = getMathChild(el, "e");

  const leftDelim = mapDelimiter(beginChr);
  const rightDelim = mapDelimiter(endChr);

  return `\\left${leftDelim}${e}\\right${rightDelim}`;
}

function mapDelimiter(chr: string): string {
  const map: Record<string, string> = {
    "(": "(",
    ")": ")",
    "[": "[",
    "]": "]",
    "{": "\\{",
    "}": "\\}",
    "|": "|",
    "‖": "\\|",
    "⌈": "\\lceil",
    "⌉": "\\rceil",
    "⌊": "\\lfloor",
    "⌋": "\\rfloor",
    "⟨": "\\langle",
    "⟩": "\\rangle",
    "": ".",
  };
  return map[chr] || chr;
}

/**
 * 函数 m:func
 * 如 lim, sin, cos, log 等
 */
function convertFunc(el: Element): string {
  const fName = getMathChild(el, "fName");
  const e = getMathChild(el, "e");

  // 检查是否是极限等特殊函数
  const funcName = fName.trim();

  if (/lim/i.test(funcName)) {
    // 极限特殊处理
    const limLow = el.getElementsByTagNameNS(MATH_NS, "limLow")[0];
    if (limLow) {
      return convertLimLow(limLow);
    }
    return `\\lim ${e}`;
  }

  const latexFunc = mapFunction(funcName);
  if (latexFunc) {
    // 函数名 + 参数，确保参数有括号包裹
    if (e && e !== "{}") {
      return `${latexFunc} ${e}`;
    }
    return `${latexFunc} {${e}}`;
  }

  // 未识别的函数名：使用 \operatorname 确保正体渲染
  if (funcName) {
    return `\\operatorname{${funcName}} ${e}`;
  }

  return e;
}

function mapFunction(name: string): string | null {
  const trimmed = name.trim().toLowerCase();
  const map: Record<string, string> = {
    "sin": "\\sin",
    "cos": "\\cos",
    "tan": "\\tan",
    "cot": "\\cot",
    "sec": "\\sec",
    "csc": "\\csc",
    "arcsin": "\\arcsin",
    "arccos": "\\arccos",
    "arctan": "\\arctan",
    "sinh": "\\sinh",
    "cosh": "\\cosh",
    "tanh": "\\tanh",
    "log": "\\log",
    "ln": "\\ln",
    "lg": "\\lg",
    "exp": "\\exp",
    "min": "\\min",
    "max": "\\max",
    "inf": "\\inf",
    "sup": "\\sup",
    "lim": "\\lim",
    "det": "\\det",
    "dim": "\\dim",
    "gcd": "\\gcd",
    "hom": "\\hom",
    "ker": "\\ker",
    "arg": "\\arg",
    "deg": "\\deg",
    "pr": "\\Pr",
    "mod": "\\bmod",
    "sgn": "\\operatorname{sgn}",
    "argmax": "\\operatorname{argmax}",
    "argmin": "\\operatorname{argmin}",
    "diag": "\\operatorname{diag}",
    "rank": "\\operatorname{rank}",
    "trace": "\\operatorname{tr}",
    "tr": "\\operatorname{tr}",
    "adj": "\\operatorname{adj}",
    "erf": "\\operatorname{erf}",
    "erfc": "\\operatorname{erfc}",
    "sinc": "\\operatorname{sinc}",
    "sign": "\\operatorname{sign}",
    "card": "\\operatorname{card}",
    "dom": "\\operatorname{dom}",
    "ran": "\\operatorname{ran}",
    "im": "\\operatorname{Im}",
    "re": "\\operatorname{Re}",
    "var": "\\operatorname{Var}",
    "cov": "\\operatorname{Cov}",
    "corr": "\\operatorname{Corr}",
  };
  return map[trimmed] || null;
}

/**
 * 方程组 m:eqArr
 */
function convertEqArr(el: Element): string {
  const rows: string[] = [];
  const rowEls = el.getElementsByTagNameNS(MATH_NS, "e");
  for (let i = 0; i < rowEls.length; i++) {
    rows.push(convertChildren(rowEls[i]));
  }
  return `\\begin{aligned} ${rows.join(" \\\\ ")} \\end{aligned}`;
}

/**
 * 矩阵 m:m
 */
function convertMatrix(el: Element): string {
  const rows: string[] = [];
  const rowEls = el.getElementsByTagNameNS(MATH_NS, "mr");

  for (let i = 0; i < rowEls.length; i++) {
    const cells: string[] = [];
    const cellEls = rowEls[i].getElementsByTagNameNS(MATH_NS, "e");
    for (let j = 0; j < cellEls.length; j++) {
      cells.push(convertChildren(cellEls[j]));
    }
    rows.push(cells.join(" & "));
  }

  // 检查是否有括号
  const mPr = el.getElementsByTagNameNS(MATH_NS, "mPr")[0];
  const mcsEl = mPr?.getElementsByTagNameNS(MATH_NS, "mcs")[0];
  const hasBrackets = !!mcsEl;

  const env = hasBrackets ? "pmatrix" : "matrix";
  return `\\begin{${env}} ${rows.join(" \\\\ ")} \\end{${env}}`;
}

/**
 * 重音符号 m:acc
 * 如向量、帽子等
 */
function convertAcc(el: Element): string {
  const accPr = el.getElementsByTagNameNS(MATH_NS, "accPr")[0];
  const chrEl = accPr?.getElementsByTagNameNS(MATH_NS, "chr")[0];
  const chr = chrEl?.getAttribute("m:val") || chrEl?.getAttribute("val") || "⃗";

  const e = getMathChild(el, "e");
  const accent = mapAccent(chr);

  return `${accent}{${e}}`;
}

function mapAccent(chr: string): string {
  const map: Record<string, string> = {
    "⃗": "\\vec",
    "⃖": "\\vec",
    "^": "\\hat",
    "̂": "\\hat",
    "̃": "\\tilde",
    "̄": "\\bar",
    "̇": "\\dot",
    "̈": "\\ddot",
    "̌": "\\check",
    "̆": "\\breve",
    "⏞": "\\overbrace",
    "⏟": "\\underbrace",
  };
  return map[chr] || "\\vec";
}

/**
 * 上划线/下划线 m:bar
 */
function convertBar(el: Element): string {
  const barPr = el.getElementsByTagNameNS(MATH_NS, "barPr")[0];
  const posEl = barPr?.getElementsByTagNameNS(MATH_NS, "pos")[0];
  const pos = posEl?.getAttribute("m:val") || posEl?.getAttribute("val") || "top";

  const e = getMathChild(el, "e");

  if (pos === "bot") {
    return `\\underline{${e}}`;
  }
  return `\\overline{${e}}`;
}

/**
 * 下极限 m:limLow
 */
function convertLimLow(el: Element): string {
  const e = getMathChild(el, "e");
  const lim = getMathChild(el, "lim");

  return `{${e}}_{${lim}}`;
}

/**
 * 上极限 m:limUpp
 */
function convertLimUpp(el: Element): string {
  const e = getMathChild(el, "e");
  const lim = getMathChild(el, "lim");

  return `{${e}}^{${lim}}`;
}

/**
 * 底部字符 m:groupChr
 * 如下方大括号
 */
function convertGroupChr(el: Element): string {
  const groupChrPr = el.getElementsByTagNameNS(MATH_NS, "groupChrPr")[0];
  const chrEl = groupChrPr?.getElementsByTagNameNS(MATH_NS, "chr")[0];
  const chr = chrEl?.getAttribute("m:val") || chrEl?.getAttribute("val") || "⏟";

  const e = getMathChild(el, "e");

  if (chr === "⏟" || chr === "_") {
    return `\\underbrace{${e}}`;
  } else if (chr === "⏞" || chr === "^") {
    return `\\overbrace{${e}}`;
  }

  return e;
}

/**
 * 边框 m:borderBox
 */
function convertBorderBox(el: Element): string {
  const e = getMathChild(el, "e");
  return `\\boxed{${e}}`;
}

/**
 * 获取指定标签的数学子元素的 LaTeX 内容
 */
function getMathChild(parent: Element, tagName: string): string {
  const child = parent.getElementsByTagNameNS(MATH_NS, tagName)[0];
  if (!child) return "";
  return convertChildren(child);
}

/**
 * 转义 LaTeX 特殊字符
 */
function escapeLatex(text: string): string {
  // 数学符号映射
  const symbolMap: Record<string, string> = {
    "×": "\\times ",
    "÷": "\\div ",
    "±": "\\pm ",
    "∓": "\\mp ",
    "·": "\\cdot ",
    "≤": "\\leq ",
    "≥": "\\geq ",
    "≠": "\\neq ",
    "≈": "\\approx ",
    "≡": "\\equiv ",
    "∝": "\\propto ",
    "∞": "\\infty ",
    "→": "\\to ",
    "←": "\\leftarrow ",
    "↔": "\\leftrightarrow ",
    "⇒": "\\Rightarrow ",
    "⇐": "\\Leftarrow ",
    "⇔": "\\Leftrightarrow ",
    "↑": "\\uparrow ",
    "↓": "\\downarrow ",
    "∈": "\\in ",
    "∉": "\\notin ",
    "⊂": "\\subset ",
    "⊃": "\\supset ",
    "⊆": "\\subseteq ",
    "⊇": "\\supseteq ",
    "∪": "\\cup ",
    "∩": "\\cap ",
    "∅": "\\emptyset ",
    "∀": "\\forall ",
    "∃": "\\exists ",
    "¬": "\\neg ",
    "∧": "\\wedge ",
    "∨": "\\vee ",
    "∴": "\\therefore ",
    "∵": "\\because ",
    "∂": "\\partial ",
    "∇": "\\nabla ",
    "√": "\\sqrt ",
    "α": "\\alpha ",
    "β": "\\beta ",
    "γ": "\\gamma ",
    "δ": "\\delta ",
    "ε": "\\epsilon ",
    "ζ": "\\zeta ",
    "η": "\\eta ",
    "θ": "\\theta ",
    "ι": "\\iota ",
    "κ": "\\kappa ",
    "λ": "\\lambda ",
    "μ": "\\mu ",
    "ν": "\\nu ",
    "ξ": "\\xi ",
    "π": "\\pi ",
    "ρ": "\\rho ",
    "σ": "\\sigma ",
    "τ": "\\tau ",
    "υ": "\\upsilon ",
    "φ": "\\phi ",
    "χ": "\\chi ",
    "ψ": "\\psi ",
    "ω": "\\omega ",
    "Α": "A",
    "Β": "B",
    "Γ": "\\Gamma ",
    "Δ": "\\Delta ",
    "Ε": "E",
    "Ζ": "Z",
    "Η": "H",
    "Θ": "\\Theta ",
    "Ι": "I",
    "Κ": "K",
    "Λ": "\\Lambda ",
    "Μ": "M",
    "Ν": "N",
    "Ξ": "\\Xi ",
    "Ο": "O",
    "Π": "\\Pi ",
    "Ρ": "P",
    "Σ": "\\Sigma ",
    "Τ": "T",
    "Υ": "\\Upsilon ",
    "Φ": "\\Phi ",
    "Χ": "X",
    "Ψ": "\\Psi ",
    "Ω": "\\Omega ",
    "…": "\\ldots ",
    "⋯": "\\cdots ",
    "⋮": "\\vdots ",
    "⋱": "\\ddots ",
    "°": "^{\\circ}",
    "′": "'",
    "″": "''",
    "‴": "'''",
    "ℕ": "\\mathbb{N}",
    "ℤ": "\\mathbb{Z}",
    "ℚ": "\\mathbb{Q}",
    "ℝ": "\\mathbb{R}",
    "ℂ": "\\mathbb{C}",
    "ℵ": "\\aleph ",
    "ℏ": "\\hbar ",
    "ℓ": "\\ell ",
    "ℑ": "\\Im ",
    "ℜ": "\\Re ",
    "∠": "\\angle ",
    "⊥": "\\perp ",
    "∥": "\\parallel ",
    "∘": "\\circ ",
    "⊕": "\\oplus ",
    "⊗": "\\otimes ",
    "⊙": "\\odot ",
    "⊖": "\\ominus ",
    "⊘": "\\oslash ",
    "◇": "\\diamond ",
    "□": "\\Box ",
    "△": "\\triangle ",
  };

  let result = "";
  for (const char of text) {
    if (symbolMap[char]) {
      result += symbolMap[char];
    } else if ("#$%&~_^\\{}".includes(char)) {
      result += "\\" + char + " ";
    } else {
      result += char;
    }
  }

  // 合并多余空格
  return result.replace(/\s+/g, " ").trim();
}
