import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  ArrowLeft, FileText, FileSpreadsheet,
  Sparkles, Download, Loader2,
} from "lucide-react";
import { useAuthStore } from "@/stores/auth";
import { lectureService } from "@/services/lecture";
import { examPaperService } from "@/services/examPaper";
import { toast } from "@/stores/ui";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card } from "@/components/ui/Card";
import { Spinner } from "@/components/ui/Spinner";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ExtractReviewModal } from "@/components/extract/ExtractReviewModal";
import { parseDocxFromBase64, renderDocxItems } from "@/lib/docx-parser";
import "katex/dist/katex.min.css";
import type { Lecture, ExamPaper } from "@/types";

export default function ResourcePreviewPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const { teacher } = useAuthStore();

  const resourceType = searchParams.get("type") as "lecture" | "examPaper" | null;
  const [loading, setLoading] = useState(true);
  const [lecture, setLecture] = useState<Lecture | null>(null);
  const [examPaper, setExamPaper] = useState<ExamPaper | null>(null);
  const [extractModal, setExtractModal] = useState<{
    open: boolean;
    resourceId: string;
    resourceType: "examPaper" | "lecture";
    resourceTitle: string;
    chapterIds: string[];
    knowledgePointIds: string[];
    grade: string;
    schoolYear: string;
  } | null>(null);

  const [docPreview, setDocPreview] = useState<{
    loading: boolean;
    html: string;
    error: string;
  }>({ loading: false, html: "", error: "" });

  const resource = lecture || examPaper;

  useEffect(() => {
    if (!id || !resourceType) {
      toast.error("参数错误");
      navigate("/resources");
      return;
    }

    const loadData = async () => {
      setLoading(true);
      try {
        if (resourceType === "lecture") {
          const data = await lectureService.getLecture(id);
          setLecture(data);
        } else {
          const data = await examPaperService.getPaper(id);
          setExamPaper(data);
        }
      } catch (e) {
        toast.error("加载失败", e instanceof Error ? e.message : undefined);
        navigate("/resources");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [id, resourceType, navigate]);

  useEffect(() => {
    if (resource && resource.originalFileUrl && resource.originalFileName) {
      if (resource.originalFileName.endsWith(".docx") || resource.originalFileName.endsWith(".doc")) {
        loadDocxPreview();
      }
    }
  }, [resource]);

  const loadDocxPreview = async () => {
    if (!resource?.originalFileUrl) return;
    setDocPreview({ loading: true, html: "", error: "" });
    try {
      const fileUrl = resource.originalFileUrl;
      
      let base64: string;
      if (fileUrl.startsWith("data:")) {
        base64 = fileUrl;
      } else {
        const response = await fetch(fileUrl);
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const blob = await response.blob();
        if (blob.size === 0) {
          throw new Error("文件为空");
        }
        base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = () => reject(new Error("文件读取失败"));
          reader.readAsDataURL(blob);
        });
      }
      
      const parseResult = await parseDocxFromBase64(base64);
      const html = renderDocxItems(parseResult.items);
      setDocPreview({ loading: false, html, error: "" });
    } catch (error) {
      setDocPreview({ loading: false, html: "", error: `加载失败: ${error instanceof Error ? error.message : "未知错误"}` });
    }
  };
  if (!resource) {
    if (loading) {
      return (
        <div className="flex items-center justify-center py-20">
          <Spinner size={24} />
        </div>
      );
    }
    return null;
  }

  const isExtracted = resource.extractStatus === "done";
  const isExtracting = resource.extractStatus === "extracting";
  const hasOriginalFile = !!resource.originalFileUrl;

  const handleOpenExtract = () => {
    setExtractModal({
      open: true,
      resourceId: resource.id,
      resourceType,
      resourceTitle: resource.title,
      chapterIds: resource.chapterIds,
      knowledgePointIds: resource.knowledgePointIds,
      grade: resource.grade,
      schoolYear: resource.schoolYear,
    });
  };

  const handleExtractConfirmed = () => {
    setExtractModal(null);
    window.location.reload();
  };

  const getDocUrl = () => {
    if (!resource.originalFileUrl) return "";
    const fileName = resource.originalFileName || "";
    if (fileName.endsWith(".pdf")) {
      return resource.originalFileUrl;
    }
    return "";
  };

  return (
    <div>
      <PageHeader
        title={resource.title}
        description={`${resourceType === "lecture" ? "讲义" : "试卷"}原稿预览`}
        icon={resourceType === "lecture" ? <FileText className="w-5 h-5" /> : <FileSpreadsheet className="w-5 h-5" />}
        action={
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => navigate("/resources")}>
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            {hasOriginalFile && (
              <a
                href={resource.originalFileUrl}
                download={resource.originalFileName}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-gold-600 bg-gold-50 rounded-lg hover:bg-gold-100 transition-colors"
              >
                <Download className="w-4 h-4" />
                下载原稿
              </a>
            )}
          </div>
        }
      />

      <div className="max-w-6xl mx-auto">
        <Card className="mb-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <Badge variant={isExtracted ? "teal" : "amber"}>
                {isExtracted ? "已拆解" : "待拆解"}
              </Badge>
              <span className="text-sm text-ink-500">
                {resourceType === "lecture" ? "讲义" : "试卷"}原稿
              </span>
              {resource.originalFileName && (
                <span className="text-xs text-ink-400">
                  文件：{resource.originalFileName}
                </span>
              )}
            </div>
            {!isExtracted && (
              <Button
                variant="gold"
                onClick={handleOpenExtract}
                loading={isExtracting}
              >
                <Sparkles className="w-4 h-4" />
                {isExtracting ? "拆解中..." : "AI拆解"}
              </Button>
            )}
          </div>
        </Card>

        <Card className="overflow-hidden">
          <div className="bg-ink-50 p-4 border-b border-ink-200">
            <div className="flex items-center gap-2 text-sm text-ink-600">
              <FileText className="w-4 h-4" />
              <span>文档预览（只读模式）</span>
            </div>
          </div>

          {hasOriginalFile ? (
            <div className="h-[70vh] bg-white overflow-y-auto">
              {resource.originalFileName.endsWith(".docx") || resource.originalFileName.endsWith(".doc") ? (
                <div className="p-8">
                  {docPreview.loading ? (
                    <div className="flex items-center justify-center py-20">
                      <Loader2 className="w-6 h-6 animate-spin text-ink-400" />
                      <span className="ml-2 text-sm text-ink-500">正在解析文档...</span>
                    </div>
                  ) : docPreview.error ? (
                    <div className="text-center py-20 text-red-600">
                      {docPreview.error}
                    </div>
                  ) : docPreview.html ? (
                    <div dangerouslySetInnerHTML={{ __html: docPreview.html }} />
                  ) : (
                    <div className="text-center py-20 text-ink-400">
                      文档内容为空
                    </div>
                  )}
                </div>
              ) : resource.originalFileName.endsWith(".pdf") ? (
                <iframe
                  src={resource.originalFileUrl}
                  title={resource.title}
                  className="w-full h-full border-none"
                  allow="autoplay; clipboard-write"
                />
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <FileText className="w-16 h-16 text-ink-200 mb-4" />
                  <div className="text-lg font-medium text-ink-900 mb-2">不支持的文件格式</div>
                  <div className="text-sm text-ink-500">当前仅支持预览 DOCX/DOC 和 PDF 格式的文档</div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <FileText className="w-16 h-16 text-ink-200 mb-4" />
              <div className="text-lg font-medium text-ink-900 mb-2">暂无原稿文件</div>
              <div className="text-sm text-ink-500">该资源没有上传原始文档，无法预览原稿</div>
            </div>
          )}
        </Card>

        {!isExtracted && hasOriginalFile && (
          <Card className="mt-4 bg-amber-50/50 border-amber-200">
            <div className="flex items-start gap-3 p-4">
              <Sparkles className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-medium text-amber-800 mb-1">AI智能拆解</div>
                <div className="text-sm text-amber-700">
                  点击上方「AI拆解」按钮，系统将自动识别文档结构，将文档切分为知识块和题目。
                  支持根据提示词自动识别："一、"表示知识块，"例1"表示题目，"【答案】""【解析】"等表示题目对应的答案解析。
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>

      {extractModal && (
        <ExtractReviewModal
          open={extractModal.open}
          onClose={() => setExtractModal(null)}
          resourceId={extractModal.resourceId}
          resourceType={extractModal.resourceType}
          resourceTitle={extractModal.resourceTitle}
          chapterIds={extractModal.chapterIds}
          knowledgePointIds={extractModal.knowledgePointIds}
          grade={extractModal.grade}
          schoolYear={extractModal.schoolYear}
          onConfirmed={handleExtractConfirmed}
        />
      )}
    </div>
  );
}